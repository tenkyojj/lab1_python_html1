// Задание 1, вариант 6
// Проверить, корректная ли дата, не используя объект Date.

const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Введите день, месяц и год через пробел: ", function(answer) {
    const parts = answer.trim().split(/\s+/);
    const day = Number(parts[0]);
    const month = Number(parts[1]);
    const year = Number(parts[2]);

    let correct = true;

    if (parts.length !== 3 || !Number.isInteger(day) ||
        !Number.isInteger(month) || !Number.isInteger(year) ||
        year < 1 || month < 1 || month > 12) {
        correct = false;
    } else {
        let daysInMonth = 31;

        if (month === 4 || month === 6 || month === 9 || month === 11) {
            daysInMonth = 30;
        } else if (month === 2) {
            const leap = (year % 400 === 0) ||
                (year % 4 === 0 && year % 100 !== 0);

            if (leap) {
                daysInMonth = 29;
            } else {
                daysInMonth = 28;
            }
        }

        if (day < 1 || day > daysInMonth) {
            correct = false;
        }
    }

    if (correct) {
        console.log("Дата корректная");
    } else {
        console.log("Дата некорректная");
    }

    rl.close();
});
