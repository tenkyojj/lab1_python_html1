// Задание 4, вариант 6
// Найти самое длинное слово в предложении.

const sentence = "Сегодня я изучаю основы программирования на JavaScript";

const words = sentence.split(" ");
let longest = "";

for (let i = 0; i < words.length; i++) {
    let word = words[i].replace(/[.,!?;:]/g, "");

    if (word.length > longest.length) {
        longest = word;
    }
}

console.log("Предложение:", sentence);
console.log("Самое длинное слово:", longest);
