// Задание 2, вариант 6
// Часть А: сумма между первым и последним элементами,
// которые отличаются от числа e не больше чем на 10^-5.
// Часть Б: удалить числа, у которых сумма цифр целой части — простое число.

const numbers = [1.2, 2.7, 2.718281, 4.5, 7.1, 2.71828, 10.4, 13.6];

let first = -1;
let last = -1;

for (let i = 0; i < numbers.length; i++) {
    if (Math.abs(numbers[i] - Math.E) <= 0.00001) {
        if (first === -1) {
            first = i;
        }
        last = i;
    }
}

let sum = 0;

if (first !== -1 && last !== -1 && first < last) {
    for (let i = first + 1; i < last; i++) {
        sum += numbers[i];
    }
    console.log("Сумма между первым и последним подходящими элементами:", sum);
} else {
    console.log("Подходящих двух элементов для суммы не найдено.");
}

function isPrime(number) {
    if (number < 2) {
        return false;
    }

    for (let i = 2; i < number; i++) {
        if (number % i === 0) {
            return false;
        }
    }
    return true;
}

function digitSum(number) {
    number = Math.abs(Math.trunc(number));
    let sum = 0;

    while (number > 0) {
        sum += number % 10;
        number = Math.floor(number / 10);
    }

    return sum;
}

const before = numbers.slice();

for (let i = numbers.length - 1; i >= 0; i--) {
    if (isPrime(digitSum(numbers[i]))) {
        numbers.splice(i, 1);
    }
}

console.log("Исходный массив:", before);
console.log("Массив после удаления:", numbers);
