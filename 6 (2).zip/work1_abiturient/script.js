// Лабораторная работа 6
// Проверка формы абитуриента и вывод введённых данных.

const form = document.getElementById("admissionForm");
const formMessage = document.getElementById("formMessage");
const result = document.getElementById("result");
const resultData = document.getElementById("resultData");

function showError(input, message) {
    input.classList.add("invalid");
    const error = input.parentElement.querySelector(".error");

    if (error) {
        error.textContent = message;
    }
}

function clearError(input) {
    input.classList.remove("invalid");
    const error = input.parentElement.querySelector(".error");

    if (error) {
        error.textContent = "";
    }
}

function validateForm() {
    let valid = true;
    const requiredInputs = form.querySelectorAll("[required]");

    formMessage.textContent = "";

    for (let i = 0; i < requiredInputs.length; i++) {
        const input = requiredInputs[i];

        if (input.type === "checkbox") {
            const agreeError = document.getElementById("agreeError");

            if (!input.checked) {
                agreeError.textContent = "Нужно подтвердить согласие.";
                valid = false;
            } else {
                agreeError.textContent = "";
            }
            continue;
        }

        if (input.value.trim() === "") {
            showError(input, "Это поле обязательно для заполнения.");
            valid = false;
        } else {
            clearError(input);
        }
    }

    const surname = document.getElementById("surname");
    const firstname = document.getElementById("firstname");

    if (surname.value.trim() && !/^[а-яёa-z -]+$/i.test(surname.value.trim())) {
        showError(surname, "Введите фамилию буквами.");
        valid = false;
    }

    if (firstname.value.trim() && !/^[а-яёa-z -]+$/i.test(firstname.value.trim())) {
        showError(firstname, "Введите имя буквами.");
        valid = false;
    }

    const birthdate = document.getElementById("birthdate");
    if (birthdate.value) {
        const selectedDate = new Date(birthdate.value + "T00:00:00");
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate >= today) {
            showError(birthdate, "Дата рождения должна быть в прошлом.");
            valid = false;
        }
    }

    const email = document.getElementById("email");
    if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
        showError(email, "Введите корректный адрес электронной почты.");
        valid = false;
    }

    const phone = document.getElementById("phone");
    if (phone.value) {
        const digits = phone.value.replace(/\D/g, "");
        if (digits.length < 10 || digits.length > 15) {
            showError(phone, "Телефон должен содержать от 10 до 15 цифр.");
            valid = false;
        }
    }

    const score = document.getElementById("score");
    if (score.value !== "") {
        const number = Number(score.value);
        if (number < 2 || number > 5) {
            showError(score, "Средний балл должен быть от 2 до 5.");
            valid = false;
        }
    }

    const documents = document.getElementById("documents");
    if (documents.files.length > 0) {
        const fileName = documents.files[0].name.toLowerCase();
        if (!/\.(pdf|jpg|jpeg|png)$/.test(fileName)) {
            showError(documents, "Можно прикрепить PDF, JPG или PNG.");
            valid = false;
        } else {
            clearError(documents);
        }
    }

    if (!valid) {
        formMessage.textContent = "Проверьте поля формы и исправьте ошибки.";
    }

    return valid;
}

function addResultLine(title, value) {
    const p = document.createElement("p");
    const strong = document.createElement("strong");
    strong.textContent = title + ": ";
    p.appendChild(strong);
    p.appendChild(document.createTextNode(value || "Не указано"));
    resultData.appendChild(p);
}

form.addEventListener("submit", function(event) {
    event.preventDefault();

    if (!validateForm()) {
        result.hidden = true;
        return;
    }

    resultData.innerHTML = "";

    addResultLine("Фамилия", form.elements.surname.value.trim());
    addResultLine("Имя", form.elements.firstname.value.trim());
    addResultLine("Отчество", form.elements.patronymic.value.trim());
    addResultLine("Дата рождения", form.elements.birthdate.value);
    addResultLine("Электронная почта", form.elements.email.value.trim());
    addResultLine("Телефон", form.elements.phone.value.trim());
    addResultLine("Предыдущее образование", form.elements.education.value);
    addResultLine("Направление подготовки", form.elements.specialty.value);
    addResultLine("Форма обучения", form.elements["form-study"].value);
    addResultLine("Средний балл", form.elements.score.value);
    addResultLine("Документ", form.elements.documents.files.length
        ? form.elements.documents.files[0].name : "Не прикреплён");
    addResultLine("Комментарий", form.elements.about.value.trim());

    result.hidden = false;
    form.reset();

    const errors = form.querySelectorAll(".error");
    for (let i = 0; i < errors.length; i++) {
        errors[i].textContent = "";
    }

    const invalidInputs = form.querySelectorAll(".invalid");
    for (let i = 0; i < invalidInputs.length; i++) {
        invalidInputs[i].classList.remove("invalid");
    }

    formMessage.textContent = "";
    result.scrollIntoView({ behavior: "smooth" });
});

form.addEventListener("reset", function() {
    formMessage.textContent = "";
    const errors = form.querySelectorAll(".error");
    for (let i = 0; i < errors.length; i++) {
        errors[i].textContent = "";
    }

    const invalidInputs = form.querySelectorAll(".invalid");
    for (let i = 0; i < invalidInputs.length; i++) {
        invalidInputs[i].classList.remove("invalid");
    }
});
